The delivery guide aims to communicate how the WVD DevOps automation solution is designed and how it can be delivered. Given the fundamental changes when moving from the Fall 2019 version to the Spring Release in 2020, the delivery guide is split into the:

- [Fall 2019 version ](/Delivery-Guide/2019-GA-Release) and
- [Latest version (2020 Spring update and after)](/Delivery-Guide/Latest-Release) 