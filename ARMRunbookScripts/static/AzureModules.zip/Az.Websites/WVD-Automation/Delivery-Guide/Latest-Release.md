This section describes the latest version of WVD automation solution (Spring 2020 Update and later).

It contains the sub-chapters
- [Deployment](/Delivery-Guide/Latest-Release/Deployment)
- [Repository Structure & Flow](/Delivery-Guide/Latest-Release/Repository-Structure-&-Flow)

[[_TOC_]]

---

