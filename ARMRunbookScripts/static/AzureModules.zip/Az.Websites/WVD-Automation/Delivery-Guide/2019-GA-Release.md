This section describes the Fall 2019 version of WVD automation solution.

It contains the sub-chapters
- [Deployment](/Delivery-Guide/2019-GA-Release/Deployment)
- [Repository Structure & Flow](/Delivery-Guide/2019-GA-Release/Repository-Structure-&-Flow)
- [Troubleshooting](/Delivery-Guide/2019-GA-Release/Troubleshooting)
- [Examples](/Delivery-Guide/2019-GA-Release/Examples)

[[_TOC_]]

---